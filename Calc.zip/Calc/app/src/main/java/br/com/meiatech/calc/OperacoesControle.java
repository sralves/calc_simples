package br.com.meiatech.calc;

/**
 * Created by Edivan on 10/07/2016.
 */
public class OperacoesControle {
    private Operacoes op = new Operacoes();

    public double somar(String num1, String num2){
        double x = Double.parseDouble(num1);
        double y = Double.parseDouble(num2);
        op.setN1(x);
        op.setN2(y);
        return op.somar();
    }

    public double sub(String num1, String num2){
        double x = Double.parseDouble(num1);
        double y = Double.parseDouble(num2);
        op.setN1(x);
        op.setN2(y);
        return op.sub();
    }

    public double div(String num1, String num2){
        double x = Double.parseDouble(num1);
        double y = Double.parseDouble(num2);
        op.setN1(x);
        op.setN2(y);
        return op.div();
    }

    public double mult(String num1, String num2){
        double x = Double.parseDouble(num1);
        double y = Double.parseDouble(num2);
        op.setN1(x);
        op.setN2(y);
        return op.mult();
    }

    public double porc(String num1, String num2){
        double x = Double.parseDouble(num1);
        double y = Double.parseDouble(num2);
        op.setN1(x);
        op.setN2(y);
        return op.porc();
    }
}
