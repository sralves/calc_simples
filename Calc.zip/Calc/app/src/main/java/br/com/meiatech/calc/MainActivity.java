package br.com.meiatech.calc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edtNum;
    private TextView resuldado;
    private String numero;
    private Button soma,sub, div, mult, igual;

    boolean mSoma = false;
    boolean mSubtracao = false;
    boolean mMultiplicacao = false;
    boolean mDivisao = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNum = (EditText)findViewById(R.id.edt_num);
        resuldado = (TextView)findViewById(R.id.txt_resul);
        soma = (Button)findViewById(R.id.btn_soma);
        sub = (Button)findViewById(R.id.btn_sub);
        div = (Button)findViewById(R.id.btn_div);
        mult = (Button)findViewById(R.id.btn_mult);

        igual = (Button)findViewById(R.id.btn_igual);

        final OperacoesControle opControle = new OperacoesControle();

        final String[] num = new String[2];

        soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoma = true;
                num[0] = numero;
                edtNum.setText("");
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDivisao = true;
                num[0] = numero;
                edtNum.setText("");
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSubtracao = true;
                num[0] = numero;
                edtNum.setText("");
            }
        });

        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMultiplicacao = true;
                num[0] = numero;
                edtNum.setText("");
            }
        });

        igual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num[1] = numero;
                if (resuldado.getText() != ""){
                    num[0] = resuldado.getText().toString();
                }
                if (mSoma){
                    Double s = opControle.somar(num[0],num[1]);
                    resuldado.setText(s.toString());
                }
                if (mSubtracao){
                    Double s = opControle.sub(num[0], num[1]);
                    resuldado.setText(s.toString());
                }
                if (mMultiplicacao){
                    Double s = opControle.mult(num[0], num[1]);
                    resuldado.setText(s.toString());
                }
                if (mDivisao){
                    Double s = opControle.div(num[0], num[1]);
                    resuldado.setText(s.toString());
                }

                edtNum.setText("");

                mSoma = false;
                mSubtracao = false;
                mMultiplicacao = false;
                mDivisao = false;
            }
        });


    }

    public void onClickBtn0(View view){
        numero = edtNum.getText().toString();
        numero = numero + "0";
        edtNum.setText(numero);
    }

    public void onClickBtn1(View view){
        numero = edtNum.getText().toString();
        numero = numero + "1";
        edtNum.setText(numero);
    }

    public void onClickBtn2(View view){
        numero = edtNum.getText().toString();
        numero = numero + "2";
        edtNum.setText(numero);
    }

    public void onClickBtn3(View view){
        numero = edtNum.getText().toString();
        numero = numero + "3";
        edtNum.setText(numero);
    }

    public void onClickBtn4(View view){
        numero = edtNum.getText().toString();
        numero = numero + "4";
        edtNum.setText(numero);
    }

    public void onClickBtn5(View view){
        numero = edtNum.getText().toString();
        numero = numero + "5";
        edtNum.setText(numero);
    }

    public void onClickBtn6(View view){
        numero = edtNum.getText().toString();
        numero = numero + "6";
        edtNum.setText(numero);
    }

    public void onClickBtn7(View view){
        numero = edtNum.getText().toString();
        numero = numero + "7";
        edtNum.setText(numero);
    }

    public void onClickBtn8(View view){
        numero = edtNum.getText().toString();
        numero = numero + "8";
        edtNum.setText(numero);
    }

    public void onClickBtn9(View view){
        numero = edtNum.getText().toString();
        numero = numero + "9";
        edtNum.setText(numero);
    }
    //Operações
    /*
    public void onClickBtnSoma(View view){
        numero = edtNum.getText().toString();
        numero = numero + "+";
        edtNum.setText(numero);
    }

    public void onClickBtnSub(View view){
        numero = edtNum.getText().toString();
        numero = numero + "-";
        edtNum.setText(numero);
    }

    public void onClickBtnMult(View view){
        numero = edtNum.getText().toString();
        numero = numero + "*";
        edtNum.setText(numero);
    }

    public void onClickBtnDiv(View view){
        numero = edtNum.getText().toString();
        numero = numero + "/";
        edtNum.setText(numero);
    }
    */
    public void onClickBtnLimar(View view){
        resuldado.setText("");
        edtNum.setText("");
    }
}
